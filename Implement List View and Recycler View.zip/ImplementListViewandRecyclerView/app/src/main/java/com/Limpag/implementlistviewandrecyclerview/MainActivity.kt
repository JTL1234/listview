package com.Limpag.implementlistviewandrecyclerview

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val simpleListView = findViewById<ListView>(R.id.simpleListView)

        val items1 = arrayOf("Item 1", "Item 2", "Item 3", "Item 4", "Item 5")

        val adapter1 = ArrayAdapter(this, android.R.layout.simple_list_item_1, items1)
        simpleListView.adapter = adapter1

        val customListView = findViewById<ListView>(R.id.customListView)

        val items2 = arrayOf("Custom Item 1", "Custom Item 2", "Custom Item 3", "Custom Item 4", "Custom Item 5")

        val adapter2 = CustomAdapter(this, items2)
        customListView.adapter = adapter2
    }
}